# -*- coding: utf-8 -*-
"""Remove the throwaway demo patient (and all its rows) from the real specialist.db."""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from src.app import create_app

PID = int(sys.argv[1]) if len(sys.argv) > 1 else 3
app = create_app({'TESTING': True, 'SECRET_KEY': 'cleanup'})
with app.app_context():
    from src.adapters.sqlite.core import get_db
    db = get_db()
    # safety: only delete if it is the demo patient
    row = db.execute("SELECT full_name FROM patient_links WHERE id=?", (PID,)).fetchone()
    if not row:
        print('no such patient', PID); sys.exit(0)
    print('deleting patient', PID, '->', row['full_name'])
    for tbl in ('vital_readings', 'medication_events', 'patient_medications', 'patient_conditions',
                'lab_results', 'allergies', 'appointments', 'followup_tasks', 'wallet_transactions'):
        db.execute(f"DELETE FROM {tbl} WHERE patient_link_id=?", (PID,))
    db.execute("DELETE FROM patient_links WHERE id=?", (PID,))
    db.commit()
    remaining = db.execute("SELECT COUNT(*) c FROM patient_links").fetchone()['c']
    print('done. remaining patients:', remaining)
