# -*- coding: utf-8 -*-
"""Seed a throwaway demo patient into the REAL specialist.db for a visual check.
Prints the new pid. Cleaned up afterwards by _cleanup_demo.py."""
import os, sys
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from src.app import create_app

app = create_app({'TESTING': True, 'SECRET_KEY': 'seed'})
with app.app_context():
    from src.adapters.sqlite.patients_repo import PatientRepository
    from src.adapters.sqlite.vitals_repo import VitalsRepository
    pr, vr = PatientRepository(), VitalsRepository()
    pid = pr.create(national_id=None, accounting_patient_id=None,
                    full_name='بیمار آزمایشی (حذف شود)', phone_number='09120000000',
                    gender='male', birthdate='1350-01-01', address=None, enrolled_by='demo')
    pr.add_condition(pid, 1)  # diabetes
    pr.add_condition(pid, 2)  # hypertension

    def series(vtype, points):
        for d, v in points:
            vr.add_reading(pid, vtype=vtype, value=v, measured_at=f'{d} 12:00:00', recorded_by='demo')

    series('hba1c', [('2024-06-01', 9.5), ('2024-09-01', 8.8), ('2024-12-01', 8.0), ('2025-03-01', 7.4)])
    series('fbs', [('2024-06-01', 210), ('2024-09-01', 180), ('2024-12-01', 150), ('2025-03-01', 135)])
    series('bp_systolic', [('2024-06-01', 162), ('2024-09-01', 150), ('2024-12-01', 140), ('2025-03-01', 131)])
    series('bp_diastolic', [('2024-06-01', 96), ('2024-09-01', 90), ('2024-12-01', 85), ('2025-03-01', 81)])
    series('ldl', [('2024-06-01', 152), ('2025-01-01', 92)])
    series('egfr', [('2024-06-01', 72), ('2025-01-01', 66)])
    series('uacr', [('2024-06-01', 45), ('2025-01-01', 38)])
    series('weight', [('2024-06-01', 95), ('2024-09-01', 92), ('2024-12-01', 90), ('2025-03-01', 88)])

    m1 = pr.add_medication(pid, drug_name='متفورمین', dose='500mg', schedule='روزی ۲ بار',
                           start_date='2024-06-15', refill_due_date='2025-07-01', notes=None)
    pr.change_dose(m1, '1000mg', change_date='2024-09-15')
    pr.add_medication(pid, drug_name='لیزینوپریل', dose='10mg', schedule='روزی ۱ بار',
                      start_date='2024-07-01', refill_due_date='2025-07-01', notes=None)
    print('DEMO_PID', pid)
