import os
import sys
import sqlite3
import pkgutil

from flask import g

from src.config.settings import Config

_initialized = False


def _load_schema_text():
    """Load bundled schema.sql in both source and frozen (PyInstaller) modes."""
    try:
        data = pkgutil.get_data('src.adapters.sqlite', 'schema.sql')
        if data:
            return data.decode('utf-8')
    except Exception:
        pass

    # Fallback 1: next to this module
    here = os.path.join(os.path.dirname(__file__), 'schema.sql')
    if os.path.exists(here):
        with open(here, 'r', encoding='utf-8') as f:
            return f.read()

    # Fallback 2: PyInstaller onefile extraction dir
    meipass = getattr(sys, '_MEIPASS', None)
    if meipass:
        for cand in (
            os.path.join(meipass, 'src', 'adapters', 'sqlite', 'schema.sql'),
            os.path.join(meipass, 'schema.sql'),
        ):
            if os.path.exists(cand):
                with open(cand, 'r', encoding='utf-8') as f:
                    return f.read()

    raise FileNotFoundError('schema.sql not found')


def _ensure_column(db, table: str, column: str, decl: str):
    try:
        cols = db.execute(f"PRAGMA table_info({table})").fetchall()
        if not any(c["name"] == column for c in cols):
            db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")
            db.commit()
    except Exception:
        pass


def _run_migrations(db):
    """Additive migrations for existing DBs (new tables come from schema IF NOT EXISTS)."""
    _ensure_column(db, "patient_links", "wallet_balance", "INTEGER NOT NULL DEFAULT 0")
    _ensure_column(db, "sms_campaigns", "campaign_type", "TEXT NOT NULL DEFAULT 'info'")
    _ensure_column(db, "sms_campaigns", "credit_amount", "INTEGER DEFAULT 0")
    _ensure_column(db, "sms_campaigns", "credit_expires_days", "INTEGER")
    # Medication lifecycle: stop date for effect/timeline tracking
    _ensure_column(db, "patient_medications", "end_date", "TEXT")


def _ensure_default_admin(db):
    """Create a default manager account (admin/admin) if no users exist."""
    try:
        row = db.execute("SELECT COUNT(*) AS c FROM users").fetchone()
        if row and row['c'] == 0:
            import bcrypt
            pw = bcrypt.hashpw('admin'.encode('utf-8'), bcrypt.gensalt())
            db.execute(
                "INSERT INTO users (username, password_hash, role, full_name, is_active) VALUES (?, ?, ?, ?, 1)",
                ('admin', pw, 'manager', 'مدیر سیستم'),
            )
            db.commit()
    except Exception:
        pass


def get_db():
    """Return the per-request connection to the specialist DB (created on first use)."""
    global _initialized
    db = getattr(g, '_database', None)
    if db is None:
        db_path = Config.DATABASE_PATH
        db_dir = os.path.dirname(db_path)
        if db_dir and not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir, exist_ok=True)
            except Exception:
                pass

        db = g._database = sqlite3.connect(db_path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")

        # Initialize schema once per process if users table is missing.
        try:
            cur = db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
            if not cur.fetchone():
                db.executescript(_load_schema_text())
                _initialized = False
        except Exception:
            try:
                db.executescript(_load_schema_text())
            except Exception:
                pass

        if not _initialized:
            try:
                db.executescript(_load_schema_text())  # idempotent (IF NOT EXISTS / OR IGNORE)
            except Exception:
                pass
            _run_migrations(db)
            _ensure_default_admin(db)
            _initialized = True

    return db


def close_connection(exception=None):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db_command():
    """CLI helper: (re)apply schema."""
    db = get_db()
    db.executescript(_load_schema_text())
    _ensure_default_admin(db)
    print('Specialist DB initialized.')
